
const navLinks = document.querySelectorAll('nav ul li a');
navLinks.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const targetId = e.target.getAttribute('href').substring(1);
    const targetSection = document.getElementById(targetId);

    window.scrollTo({
      top: targetSection.offsetTop - 50,
      behavior: 'smooth',
    });
  });
});


const skillSection = document.querySelector('#skills');
const progressBars = document.querySelectorAll('.progress-bar');

function showProgress() {
  progressBars.forEach(bar => {
    const value = bar.getAttribute('data-value');
    bar.style.width = `${value}%`;
  });
}

function handleScroll() {
  const skillSectionTop = skillSection.offsetTop - window.innerHeight + 100;
  if (window.scrollY >= skillSectionTop) {
    showProgress();
    window.removeEventListener('scroll', handleScroll);
  }
}

window.addEventListener('scroll', handleScroll);


const form = document.querySelector('form');
const inputs = document.querySelectorAll('form input, form textarea');

form.addEventListener('submit', e => {
  e.preventDefault();
  let isValid = true;

  inputs.forEach(input => {
    const errorMessage = input.nextElementSibling;
    if (input.value.trim() === '') {
      errorMessage.textContent = `${input.getAttribute('placeholder')} is required.`;
      errorMessage.style.color = 'red';
      isValid = false;
    } else {
      errorMessage.textContent = '';
    }
  });

  if (isValid) {
    alert('Thank you for contacting me! I will get back to you soon.');
    form.reset();
  }
});


const buttons = document.querySelectorAll('.cta, form button');

buttons.forEach(button => {
  button.addEventListener('mouseover', e => {
    const rect = button.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const ripple = document.createElement('span');
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.classList.add('ripple');
    button.appendChild(ripple);

    setTimeout(() => {
      ripple.remove();
    }, 600);
  });
});
